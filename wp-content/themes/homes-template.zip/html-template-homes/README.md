# Properties markup demo

A static HTML files for homes / building properties website.